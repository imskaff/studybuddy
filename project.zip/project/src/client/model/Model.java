package client.model;

import java.beans.PropertyChangeListener;
import java.util.ArrayList;
import java.util.List;
import server.model.Session;
import server.model.Student;
import server.model.Tutor;

public interface Model {

  void connect() throws Exception;

  void disconnect();

  void bookSession(Student loggedInStudent, Tutor sessionTutor, Session bookedSession) throws Exception;

  ArrayList<Session> getAllSessions();

  ArrayList<Session> getTutorSessions();

  ArrayList<Session> getBookedSessions();

  void setLoggedInStudent(Student student);

  Student getLoggedInStudent();

  void setLoggedInAdminId(int adminId);

  int getLoggedInAdminId();

  ArrayList<Tutor> getPendingTutors();

  boolean createSession(Session session);

  boolean editSession(Session session);

  boolean cancelSession(int userId, int sessionId, String userType);

  boolean deleteSession(int sessionId);

  boolean approveTutor(int tutorId);

  boolean declineTutor(int tutorId);

  boolean registerStudent(Student student);

  boolean registerTutor(Tutor tutor);

  void setLoggedInTutor(Tutor tutor);

  Tutor getLoggedInTutor();

  boolean editStudentProfile(Student student);

  void addPropertyChangeListener(PropertyChangeListener listener);

  List<String> getSubjects();

  boolean editTutorProfile(Tutor tutor);

  String login(String email, String password);

  boolean completeSession(int sessionId);
}

package client.viewmodel;

import client.model.Model;
import client.viewmodel.admin.AdminViewModel;
import client.viewmodel.student.*;
import client.viewmodel.tutor.*;

public class ViewModelFactory
{
    private SessionStudentViewModel sessionStudentViewModel;
    private SessionTutorViewModel sessionTutorViewModel;
    private TutorProfileViewModel tutorProfileViewModel;
    private StudentMainPageViewModel studentMainPageViewModel;
    private WelcomeViewModel welcomeViewModel;
    private TutorMainPageViewModel tutorMainPageViewModel;
    private CreateNewSessionViewModel createNewSessionViewModel;
    private CreateStudentProfileViewModel createStudentViewModel;
    private CreateTutorProfileViewModel createTutorViewModel;
    private AdminViewModel adminViewModel;
    private CreateNewProfileViewModel createNewProfileViewModel;
    private RulesViewModel rulesViewModel;
    private CreateStudentProfileViewModel createStudentProfileViewModel;
    private EditStudentProfileViewModel editStudentProfileViewModel;

    private ViewState viewState;

    public ViewModelFactory(Model model) {
        this.viewState = new ViewState();
        sessionStudentViewModel = new SessionStudentViewModel(model);
        sessionTutorViewModel = new SessionTutorViewModel(model);
        tutorProfileViewModel = new TutorProfileViewModel(model);
        studentMainPageViewModel = new StudentMainPageViewModel(model);
        welcomeViewModel = new WelcomeViewModel(model);
        tutorMainPageViewModel = new TutorMainPageViewModel(model, viewState);
//        createNewSessionViewModel = new CreateNewSessionViewModel(model, viewState);
        createStudentViewModel = new CreateStudentProfileViewModel(model);
        createTutorViewModel = new CreateTutorProfileViewModel(model);
        adminViewModel = new AdminViewModel(model);
        createNewSessionViewModel = new CreateNewSessionViewModel(model);
        createNewProfileViewModel = new CreateNewProfileViewModel(model);
        rulesViewModel = new RulesViewModel(model);
        createStudentProfileViewModel = new CreateStudentProfileViewModel(model);
        editStudentProfileViewModel = new EditStudentProfileViewModel(model);


    }

    public WelcomeViewModel getWelcomeViewModel() {
        return welcomeViewModel;
    }

    public SessionStudentViewModel getSessionStudentViewModel() {
        return sessionStudentViewModel;
    }

    public SessionTutorViewModel getSessionTutorViewModel() {
        return sessionTutorViewModel;
    }

    public TutorProfileViewModel getTutorProfileViewModel() {
        return tutorProfileViewModel;
    }

    public StudentMainPageViewModel getStudentMainPageViewModel() {
        return studentMainPageViewModel;
    }

    public TutorMainPageViewModel getTutorMainPageViewModel() {
        return tutorMainPageViewModel;
    }

    public CreateNewSessionViewModel getCreateNewSessionViewModel() {
        return createNewSessionViewModel;
    }
    public CreateStudentProfileViewModel getCreateStudentViewModel() {
        return createStudentViewModel;
    }

    public CreateTutorProfileViewModel getCreateTutorViewModel() {
        return createTutorViewModel;
    }

    public AdminViewModel getAdminViewModel() {
        return adminViewModel;
    }

  public CreateNewProfileViewModel getCreateNewProfileViewModel()
  {
    return createNewProfileViewModel;
  }

  public RulesViewModel getRulesViewModel()
  {
    return rulesViewModel;
  }

  public CreateStudentProfileViewModel getCreateStudentProfileViewModel()
  {
    return createStudentProfileViewModel;
  }

  public EditStudentProfileViewModel getEditStudentProfileViewModel()
  {
    return editStudentProfileViewModel;
  }

}